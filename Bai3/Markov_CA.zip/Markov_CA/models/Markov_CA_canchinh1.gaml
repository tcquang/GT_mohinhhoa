model MarkovCA_kappa1

global control: reflex {
	int tong_luc;
	int tong_luk;
	int tong_tsl;
	matrix mt_markov;
	file file_markov <- csv_file("../includes/matran_code.csv", false);
	list<int> ds_loaidat;
	file file_loaidat <- csv_file("../includes/loaidat_code.csv", false);
	file file_ht <- '../includes/ht_2015.tif';
	file file_ht_kiemchung <- '../includes/ht_2020.tif';
	float w_markov <- 1;
	float w_neighbors <- 1;
	float w_threshold <- 0;
	float v_kappa;

	action tinh_dientich {
	// tính diện tích (số ô)
		tong_luc <- 0;
		tong_luk <- 0;
		tong_tsl <- 0;
		ask cell_dat {
			if landuse = 5 {
				tong_luc <- tong_luc + 1;
			}

			if landuse = 6 {
				tong_luk <- tong_luk + 1;
			}

			if landuse = 34 {
				tong_tsl <- tong_tsl + 1;
			}

		}

	}

	action chuyendoi_sdd {
	// tạo map xác suất chuyển đổi từ ma trận
		map<pair<int, int>, float> map_markov;
		loop i from: 1 to: mt_markov.columns - 1 {
			int ldat_to <- int(mt_markov[i, 0]); // Tiêu đề cột (Loại đất đích)
			loop j from: 1 to: mt_markov.rows - 1 {
				int ldat_from <- int(mt_markov[0, j]); // Tiêu đề dòng (Loại đất nguồn)
				float xacsuat <- float(mt_markov[i, j]);

				// Lưu vào map bằng cặp Pair
				map_markov[ldat_from::ldat_to] <- xacsuat;
			}

		}

		write "Map Markov (Pair): " + map_markov;

		// Khai báo tham số trong Global (để tạo Slider điều chỉnh)
		//float w_spatial_alpha <- 0.5; //1.5; // Giá trị > 1: tăng độ co cụm; < 1: giảm độ khắt khe
		ask cell_dat parallel: true {
			ds_ld_ungvien <- [];
			xs_ungvien <- [];
			list<cell_dat> nbs <- self.neighbors;
			int total_nbs <- length(nbs);
			loop ld over: ds_loaidat {
			// 1. Tính tỷ lệ lân cận (Base Spatial Influence)
				float tile <- (nbs count (each.landuse = ld)) / total_nbs;

				// 2. Lấy xác suất Markov (Historical Rule)
				float xs_markov <- map_markov[int(self.landuse)::int(ld)];

				// 3. Công thức CA cải tiến với Lũy thừa
				// Nếu tile = 0, kết quả chắc chắn là 0 (Đúng chất CA)
				// Nếu tile > 0, w_spatial_alpha sẽ điều chỉnh mức độ ưu tiên lân cận
				float xs_tong_hop <- xs_markov * (tile ^ w_neighbors);
				if (xs_tong_hop > w_threshold) {
					add ld to: ds_ld_ungvien;
					add xs_tong_hop to: xs_ungvien;
				}

			}

			if (!empty(xs_ungvien)) {
				int vitrichon <- rnd_choice(xs_ungvien);
				self.landuse <- ds_ld_ungvien[vitrichon];
				do set_color;
			}

		}

	}

	action gan_ht_kiemchung {
		ask cell_dat {
			landuse_kc <- cell_kiemchung[self.grid_x, self.grid_y].landuse;
		}

	}

	action tinh_kappa {
	// Tạo danh mục loại đất kiểm chứng
		list<int> ds_loaidat_danhgia <- [];
		ask cell_kiemchung {
			if not (landuse in ds_loaidat_danhgia) {
			// Nếu loại đất của từng cell_dat chưa có trong danh sách thì đưa vào
			//danh sách kiểm chứng
				ds_loaidat_danhgia << landuse;
			}

		}

		ask cell_dat {
			if not (landuse in ds_loaidat_danhgia) {
				ds_loaidat_danhgia << landuse;
			}

		}

		write "In kiem tra ds_loaidat_danhgia: " + ds_loaidat_danhgia;
		// tính kappa
		v_kappa <- kappa(cell_dat collect (each.landuse), cell_dat collect (each.landuse_kc), ds_loaidat_danhgia);
		write "Kappa: " + v_kappa;
		// Tính phần trăm độ lệch tuyệt đối
		list<int> ds_slg_cell_mp; // Danh sách số lượng cell mô phỏng
		list<int> ds_slg_cell_kiemchung; // Danh sách số lượng cell thực tế
		loop ld over: ds_loaidat_danhgia {
			ds_slg_cell_mp << cell_dat count (each.landuse = ld);
			ds_slg_cell_kiemchung << cell_dat count (each.landuse_kc = ld);
		}

		write "Phần trăm sai lệch : " + percent_absolute_deviation(ds_slg_cell_kiemchung, ds_slg_cell_mp) + "%";
	}

	reflex my_reflex {
	// chuyển đổi sử dụng đất
		do chuyendoi_sdd;

		// tinh dien tích
		do tinh_dientich;
		do gan_ht_kiemchung;
		do tinh_kappa;
	}

	init {
		mt_markov <- matrix(file_markov);
		write sample(mt_markov);
		matrix data <- matrix(file_loaidat);
		write "dulieu CSV goc:" + data;
		//loop on the matrix rows (skip the first header line)
		loop i from: 1 to: data.rows - 1 {
			ds_loaidat <- ds_loaidat + int(data[0, i]);
		}

		write "DS loaidat" + ds_loaidat;
		ask cell_dat {
			do set_color;
		}

		ask cell_kiemchung {
			do to_mau;
		}

	}

}

grid cell_dat file: file_ht control: reflex neighbors: 8 {
	int landuse <- int(grid_value);
	list<cell_dat> lancan <- self neighbors_at 1;
	list<float> xs_ungvien;
	list<int> ds_ld_ungvien;
	int landuse_kc;

	init {
	}

	action set_color {
	// Tô màu theo bảng map danh sách mã loại đất và màu
		map<int, rgb> mau_loaidat <- [5::#yellowgreen, 6::#salmon, 34::#blue, 0::#white];
		color <- mau_loaidat[landuse];
	}

}

grid cell_kiemchung file: file_ht_kiemchung control: reflex neighbors: 8 {
	int landuse <- int(grid_value);

	init {
	}

	action to_mau {
		map<int, rgb> mau_loaidat <- [5::#yellowgreen, 6::#salmon, 34::#blue, 0::#white];
		color <- mau_loaidat[landuse];
	}

}

experiment "my_GUI_xp" type: gui {
	parameter "TS MKV" var: w_markov <- 1 min: 0.1 max: 1 step: 0.1;
	parameter "Lan can" var: w_neighbors <- 1 min: 0.1 max: 1 step: 0.1;
	parameter "Nguong XS UV" var: w_threshold <- 0 min: 0.1 max: 1 step: 0.1;
	output {
		display bando type: java2D {
			grid cell_dat lines: rgb(255, 255, 255);
		}

		display bieudo type: java2D {
			chart "Layer" type: series background: rgb(255, 255, 255) {
				data "DT LUC (số ô)" style: line value: tong_luc color: #yellowgreen;
				data "DT LUK" style: line value: tong_luk color: #salmon;
				data "DT TSL" style: line value: tong_tsl color: #blue;
			}

		}

		display bd_thucte type: java2D {
			grid cell_kiemchung lines: rgb(255, 255, 255);
		}

	}

}

experiment "canchinh" type: batch repeat: 5 keep_seed: true until: ( time > 4){
	parameter "Trong so lan can (Alpha)" var: w_neighbors min: 0.5 max: 3.0 step: 0.1;
	parameter "Trong so nguong XS" var: w_threshold min: 0.0 max: 0.2 step: 0.02;
	method exhaustive maximize: v_kappa;
	
}